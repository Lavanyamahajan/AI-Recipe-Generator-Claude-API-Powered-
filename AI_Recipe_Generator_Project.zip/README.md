AI Recipe Generator

1. Backend:
cd backend
npm install
node server.js

2. Frontend:
cd frontend
npm start
